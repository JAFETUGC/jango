document.addEventListener('DOMContentLoaded', () => {
    const productForm = document.getElementById('product-form');
    const productList = document.getElementById('product-list');
    const formTitle = document.getElementById('form-title');
    const productIdInput = document.getElementById('product-id');
    const cancelEditBtn = document.getElementById('cancel-edit-btn');

    const API_URL = '/api/productos';

    // --- FUNCIONES PARA INTERACTUAR CON LA API ---

    // Obtener todos los productos
    const fetchProductos = async () => {
        try {
            const response = await fetch(API_URL);
            const productos = await response.json();
            renderProductos(productos);
        } catch (error) {
            console.error('Error al obtener productos:', error);
            alert('No se pudieron cargar los productos.');
        }
    };

    // Crear o actualizar un producto
    const saveProducto = async (productoData, id = null) => {
        const url = id ? `${API_URL}/${id}` : API_URL;
        const method = id ? 'PUT' : 'POST';

        try {
            const response = await fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(productoData),
            });

            if (response.ok) {
                alert(id ? 'Producto actualizado con éxito.' : 'Producto creado con éxito.');
                resetForm();
                fetchProductos();
            } else {
                const errorData = await response.json();
                alert('Error: ' + (errorData.error || 'No se pudo guardar el producto.'));
            }
        } catch (error) {
            console.error('Error al guardar producto:', error);
            alert('Error de red al guardar el producto.');
        }
    };

    // Eliminar un producto
    const deleteProducto = async (id) => {
        if (confirm('¿Estás seguro de que quieres eliminar este producto?')) {
            try {
                const response = await fetch(`${API_URL}/${id}`, {
                    method: 'DELETE',
                });

                if (response.ok) {
                    alert('Producto eliminado con éxito.');
                    fetchProductos();
                } else {
                    alert('Error al eliminar el producto.');
                }
            } catch (error) {
                console.error('Error al eliminar producto:', error);
                alert('Error de red al eliminar el producto.');
            }
        }
    };

    // --- FUNCIONES PARA MANIPULAR EL DOM ---

    const renderProductos = (productos) => {
        productList.innerHTML = '';
        productos.forEach(producto => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${producto.nombre}</td>
                <td>${producto.precio.toFixed(2)}</td>
                <td>${producto.stock}</td>
                <td>${producto.activo ? 'Sí' : 'No'}</td>
                <td>
                    <button class="btn btn-warning" onclick="editProducto('${producto._id}')">Editar</button>
                    <button class="btn btn-danger" onclick="deleteProducto('${producto._id}')">Eliminar</button>
                </td>
            `;
            productList.appendChild(tr);
        });
    };

    const populateEditForm = (producto) => {
        formTitle.textContent = 'Actualizar Producto';
        productIdInput.value = producto._id;
        document.getElementById('nombre').value = producto.nombre;
        document.getElementById('precio').value = producto.precio;
        document.getElementById('stock').value = producto.stock;
        document.getElementById('activo').value = producto.activo.toString();
        document.getElementById('etiquetas').value = producto.etiquetas.join(', ');
        cancelEditBtn.style.display = 'inline-block';
        window.scrollTo(0, 0); // Subir hasta el formulario
    };
    
    // Hacemos 'editProducto' y 'deleteProducto' globales para que puedan ser llamadas desde el 'onclick' en el HTML
    window.editProducto = async (id) => {
        try {
            const response = await fetch(`${API_URL}/${id}`);
            const producto = await response.json();
            populateEditForm(producto);
        } catch (error) {
            console.error('Error al obtener producto para editar:', error);
            alert('No se pudo cargar el producto para editar.');
        }
    };

    window.deleteProducto = deleteProducto;

    const resetForm = () => {
        productForm.reset();
        formTitle.textContent = 'Añadir Nuevo Producto';
        productIdInput.value = '';
        cancelEditBtn.style.display = 'none';
    };

    // --- EVENT LISTENERS ---

    productForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const etiquetasString = document.getElementById('etiquetas').value;
        const etiquetasArray = etiquetasString ? etiquetasString.split(',').map(tag => tag.trim()) : [];

        const productoData = {
            nombre: document.getElementById('nombre').value,
            precio: parseFloat(document.getElementById('precio').value),
            stock: parseInt(document.getElementById('stock').value, 10),
            activo: document.getElementById('activo').value === 'true',
            etiquetas: etiquetasArray
        };

        const id = productIdInput.value;
        saveProducto(productoData, id ? id : null);
    });

    cancelEditBtn.addEventListener('click', resetForm);

    // --- INICIO ---
    fetchProductos();
});