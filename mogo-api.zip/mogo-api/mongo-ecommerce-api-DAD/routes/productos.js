// routes/productos.js
const express = require('express');
const { ObjectId } = require('mongodb');
const { getDb } = require('../db');

const router = express.Router();

// OBTENER todos los productos (READ)
router.get('/', async (req, res) => {
  try {
    const db = getDb();
    const productos = await db.collection('productos').find({}).toArray();
    res.status(200).json(productos);
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener los productos' });
  }
});

// OBTENER un producto por ID (READ)
router.get('/:id', async (req, res) => {
  try {
    const db = getDb();
    const producto = await db.collection('productos').findOne({ _id: new ObjectId(req.params.id) });
    if (producto) {
      res.status(200).json(producto);
    } else {
      res.status(404).json({ error: 'Producto no encontrado' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener el producto' });
  }
});

// CREAR un nuevo producto (CREATE)
router.post('/', async (req, res) => {
  try {
    const db = getDb();
    const nuevoProducto = req.body;
    const resultado = await db.collection('productos').insertOne(nuevoProducto);
    res.status(201).json(resultado);
  } catch (err) {
    res.status(500).json({ error: 'Error al crear el producto', details: err.message });
  }
});

// ACTUALIZAR un producto (UPDATE)
router.put('/:id', async (req, res) => {
  try {
    const db = getDb();
    const actualizaciones = req.body;
    const resultado = await db.collection('productos').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: actualizaciones }
    );
    if (resultado.matchedCount > 0) {
      res.status(200).json({ message: 'Producto actualizado correctamente' });
    } else {
      res.status(404).json({ error: 'Producto no encontrado' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error al actualizar el producto' });
  }
});

// ELIMINAR un producto (DELETE)
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const resultado = await db.collection('productos').deleteOne({ _id: new ObjectId(req.params.id) });
    if (resultado.deletedCount > 0) {
      res.status(200).json({ message: 'Producto eliminado correctamente' });
    } else {
      res.status(404).json({ error: 'Producto no encontrado' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error al eliminar el producto' });
  }
});

module.exports = router;