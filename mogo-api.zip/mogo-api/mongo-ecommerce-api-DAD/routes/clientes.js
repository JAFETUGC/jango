// routes/clientes.js
const express = require('express');
const { ObjectId } = require('mongodb');
const { getDb } = require('../db');

const router = express.Router();

// GET /api/clientes
router.get('/', async (req, res) => {
  try {
    const db = getDb();
    const clientes = await db.collection('clientes').find({}).toArray();
    res.status(200).json(clientes);
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener los clientes' });
  }
});

// GET /api/clientes/:id
router.get('/:id', async (req, res) => {
  try {
    const db = getDb();
    const cliente = await db.collection('clientes').findOne({ _id: new ObjectId(req.params.id) });
    if (cliente) {
      res.status(200).json(cliente);
    } else {
      res.status(404).json({ error: 'Cliente no encontrado' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener el cliente' });
  }
});

// POST /api/clientes
router.post('/', async (req, res) => {
  try {
    const db = getDb();
    const nuevoCliente = req.body;
    const resultado = await db.collection('clientes').insertOne(nuevoCliente);
    res.status(201).json(resultado);
  } catch (err) {
    res.status(500).json({ error: 'Error al crear el cliente' });
  }
});

// PUT /api/clientes/:id
router.put('/:id', async (req, res) => {
  try {
    const db = getDb();
    const actualizaciones = req.body;
    const resultado = await db.collection('clientes').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: actualizaciones }
    );
    if (resultado.matchedCount > 0) {
      res.status(200).json({ message: 'Cliente actualizado correctamente' });
    } else {
      res.status(404).json({ error: 'Cliente no encontrado' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error al actualizar el cliente' });
  }
});

// DELETE /api/clientes/:id
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const resultado = await db.collection('clientes').deleteOne({ _id: new ObjectId(req.params.id) });
    if (resultado.deletedCount > 0) {
      res.status(200).json({ message: 'Cliente eliminado correctamente' });
    } else {
      res.status(404).json({ error: 'Cliente no encontrado' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error al eliminar el cliente' });
  }
});

module.exports = router;